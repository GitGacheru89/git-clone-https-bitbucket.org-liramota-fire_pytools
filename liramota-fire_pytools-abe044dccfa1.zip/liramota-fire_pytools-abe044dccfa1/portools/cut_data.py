#!/usr/bin/env /share/share1/share_dff/anaconda3/bin/python
# coding: utf-8

"""
Author: Lira Mota, lmota20@gsb.columbia.edu
Data: 2019-02
"""

# %% Packages
import pandas as pd
import numpy as np

# %% Function Definition



import pandas as pd
from data_setup.stock_annual import main as stock_annual
adata = stock_annual()
adata.to_csv('/Users/liramertens/Dropbox/Projects/CashExerciseRA/data/raw_data/Compustat/stock_annual.csv')